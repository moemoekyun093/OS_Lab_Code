// Physical memory allocator, intended to allocate
// memory for user processes, kernel stacks, page table pages,
// and pipe buffers. Allocates 4096-byte pages.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"

#define SIZE 10000

void freerange(void *vstart, void *vend);
extern char end[]; // first address after kernel loaded from ELF file
                   // defined by the kernel linker script in kernel.ld

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  int use_lock;
  struct run *freelist;
} kmem;

struct node{
  int ref;
  uint pa;
};

struct node refarr[SIZE];

// Initialization happens in two phases.
// 1. main() calls kinit1() while still using entrypgdir to place just
// the pages mapped by entrypgdir on free list.
// 2. main() calls kinit2() with the rest of the physical pages
// after installing a full page table that maps them on all cores.
void
kinit1(void *vstart, void *vend)
{
  for(int i=0;i<SIZE;i++)
  {
    refarr[i].ref=-1;
  }
  initlock(&kmem.lock, "kmem");
  kmem.use_lock = 0;
  freerange(vstart, vend);
}

void
kinit2(void *vstart, void *vend)
{
  freerange(vstart, vend);
  kmem.use_lock = 1;
}

int getNumFreePages()
{
  struct run* r;
  int c=1;
  if(kmem.use_lock)
    acquire(&kmem.lock);
  r=kmem.freelist;
  while(r->next != 0x0)
  {
    // cprintf("%d\n",r->next);
    c++;
    r=r->next;
  }
  if(kmem.use_lock)
    release(&kmem.lock);
  return c;
}
int getRef(uint pa)
{
  int i;
  for(i=0;i<SIZE;i++)
  {
    if(refarr[i].pa==pa)
      break;
  }
  return refarr[i].ref;
}

int increaseRef(uint pa)
{
  int i;
  for(i=0;i<SIZE;i++)
  {
    if(refarr[i].pa==pa)
      break;
  }
  refarr[i].ref++;
  // cprintf("%d\n",refarr[i].ref);
  return 0;
  
}
int decreaseRef(uint pa)
{
  int i;
  for(i=0;i<SIZE;i++)
  {
    if(refarr[i].pa==pa)
      break;
  }
  refarr[i].ref--;
  // cprintf("%d\n",refar[i].ref);
  return 0;
  
}


void
freerange(void *vstart, void *vend)
{
  char *p;
  p = (char*)PGROUNDUP((uint)vstart);
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE){
    struct run* r=(struct run*)p;
    kfree(p);}
}
//PAGEBREAK: 21
// Free the page of physical memory pointed at by v,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
  struct run *r;
  
  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP){
    cprintf("%d\n",V2P(v) >= PHYSTOP);
    panic("kfree");}
  int i;
  int flag=0;
  for(i=0;i<SIZE;i++)
  {
    if(refarr[i].pa==V2P(v)){
      flag=1;
      break;}
  }
  if(flag){
  refarr[i].ref--;
  if(refarr[i].ref >0){
    // cprintf("%d\n",refarr[i]);
    return;}
  }


  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);

  if(kmem.use_lock)
    acquire(&kmem.lock);
  r = (struct run*)v;
  r->next = kmem.freelist;
  kmem.freelist = r;
  if(flag){
    refarr[i].ref=-1;
    // cprintf("setting %d\n",i);
    }
  if(kmem.use_lock)
    release(&kmem.lock);
}

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
char*
kalloc(void)
{
  struct run *r;

  if(kmem.use_lock)
    acquire(&kmem.lock);
  r = kmem.freelist;
  if(r){
    kmem.freelist = r->next;
    int i;
    for(i=0;i<SIZE;i++)
    {
      if(refarr[i].ref == -1)
        break;
    }
    refarr[i].pa=V2P((char*)r);
    refarr[i].ref=1;
    // cprintf("getting %d at refarr %d\n",refarr[i].pa,i);
    // cprintf("new ref %d, old ref %d\n",refarr[i].ref,refarr[i-1].ref);
  }
  if(kmem.use_lock)
    release(&kmem.lock);
  return (char*)r;
}

