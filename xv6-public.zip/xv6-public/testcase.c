#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"


int a[1000];
int main(void)
{
  printf(1, "%d\n",getNumFreePages());
  int cc = fork();
  char* p=sbrk(4096);
  if(cc != 0){
    wait();
    printf(1, "%d\n",getNumFreePages());
  }
  else{
  printf(1, "%d\n",getNumFreePages());
  a[69]=2;
  printf(1, "%d\n",getNumFreePages());
  a[999]=4;
  printf(1, "%d\n",getNumFreePages());
  }
  exit();
}
